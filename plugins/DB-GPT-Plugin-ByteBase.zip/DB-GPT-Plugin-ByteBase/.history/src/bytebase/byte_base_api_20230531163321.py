import dataclasses
from typing import List
import requests
import json
import datetime
from dateutil.tz import tzutc
import base64
import hmac
import hashlib

bytebase_domain = "http://43.156.9.162:5678"
bb_db_create_url = "/api/issue"
bb_db_query_url = "/api/issue/{}"


# submit json data by post request.
def post_json_data(url: str, json_data: dict):
    response = requests.post(url, data=json.dumps(json_data), headers=get_auth_header())
    print(response.content)
    print(response.__dict__)
    if response.status_code == requests.codes.ok:
        return response.json()
    else:
        return None

def get_with_header(url: str, headers: dict):
    response = requests.get(url, headers=headers)
    print("get_with_header=============:", response.content)
    print("get_with_header=============:", response.__dict__)
    if response.status_code == requests.codes.ok:
        return response.json()
    else:
        return None


# create database by param CreateReq, and return Response.json
def create_database(database_name: str, env: str):
    url = bytebase_domain + bb_db_create_url
    print(url)
    labels = []
    p_env = {}
    p_env["key"] = "bb.environment"
    p_env["value"] = env
    labels.append(p_env)
    labels_str = json.dumps(labels)
    print(labels_str)

    createContext = {}
    createContext["databaseName"] = database_name
    createContext["labels"] = labels_str
    createContext["instanceId"] = 102
    createContext["tableName"] = ""
    createContext["owner"] = ""
    createContext["characterSet"] = "utf8mb4"
    createContext["collation"] = "utf8mb4_general_ci"
    createContext["cluster"] = ""
    createContext_str = json.dumps(createContext)
    print(createContext_str)

    attributes = {}
    attributes["name"] = f"Create database '{database_name}'"
    attributes["type"] = "bb.issue.database.create"
    attributes["description"] = ""
    attributes["assigneeId"] = 1
    attributes["projectId"] = 103
    attributes["pipeline"] = {
                "stageList": [],
                "name": ""
            },
    attributes["createContext"] = createContext_str
    attributes["payload"] = "{}"
    print("attr===========: ", attributes)

    data = {}
    data["type"] = "IssueCreate"
    data["attributes"] = attributes
    request = {"data": data}
    print("request===========: ", request)
    return post_json_data(url, request)

def get_auth_header():
    headers = {
        "Cookie": "user=101; access-token=eyJhbGciOiJIUzI1NiIsImtpZCI6InYxIiwidHlwIjoiSldUIn0.eyJuYW1lIjoicm9vdCIsImlzcyI6ImJ5dGViYXNlIiwic3ViIjoiMTAxIiwiYXVkIjpbImJiLnVzZXIuYWNjZXNzLnByb2QiXSwiZXhwIjoxNjg1NTgzOTAwLCJpYXQiOjE2ODU0OTc1MDB9.KX9E5oxvevRnBzbMkS5V0dvNIHbiHBbRfXwToAAjt5A; refresh-token=eyJhbGciOiJIUzI1NiIsImtpZCI6InYxIiwidHlwIjoiSldUIn0.eyJuYW1lIjoicm9vdCIsImlzcyI6ImJ5dGViYXNlIiwic3ViIjoiMTAxIiwiYXVkIjpbImJiLnVzZXIucmVmcmVzaC5wcm9kIl0sImV4cCI6MTY4NjEwMjMwMCwiaWF0IjoxNjg1NDk3NTAwfQ._i-A0SsycRtdF1DwPxREDf7q7WgiMVDi3xcw3IZqaJs",
        "Content-type": "application/json",
    }
    return headers

def query_database_status(id: int):
    url = bytebase_domain + bb_db_query_url.format(id)
    return get_with_header(url, get_auth_header())


###################################################################
##  test create database by bytebase  ##################################

response_json = create_database("dbgpt_test7", "test")
print("response_json==============:", response_json)

response_data = response_json["data"]
print("response_data==============:", response_data)
id = None

if response_data:
    print("response_data is not null")

if response_data.get('id'):
    id = response_data["id"]
    print("id=============", id)

if id != None:
    ## 请求查询建库状态
    query_json = query_database_status(id)
    print("query_json===========:", query_json)
    if query_json and "data" in query_json:
        query_json_data = query_json["data"]
        print("query_json_data=============:", query_json_data)
        if query_json_data and "attributes" in query_json_data and "status" in query_json_data["attributes"]:
            status = query_json_data["attributes"]["status"]
            if status == "OPEN":
                print("current create database issue is 'OPEN' status!")
            elif status == "DONE":
                print("current create database issue is 'DONE' status!")
            else:
                print(f"current create database issue is '{status}' status!")