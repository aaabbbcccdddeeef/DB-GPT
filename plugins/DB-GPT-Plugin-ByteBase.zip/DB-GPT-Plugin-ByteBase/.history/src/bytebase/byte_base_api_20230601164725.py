import requests
import json
import time
import datetime

bytebase_domain = "http://43.156.9.162:5678"
bb_db_create_url = "/api/issue"
bb_db_query_url = "/api/issue/{}"
bb_overview_url = bytebase_domain + "/db"
bb_create_sheet_url = "/api/sheet"
bb_issue_url = bytebase_domain + "/issue"
bb_instance_url = "/api/instance"
bb_project_url = "/api/project"
bb_database_url = "/api/database"
bb_database_detail_page_template = bytebase_domain + "/db/{}-{}#overview"

DEFAULT_PROJECT = {"project_id": 103, "project_name": "DB-GPT"}
DEFAULT_ENV = {"env_id": "101", "env_name": "test"}
DEFAULT_INSTANCE_TEST = {"instance_id": 102, "instance_name": "mysql_test"}
DEFAULT_INSTANCE_PROD = {"instance_id": 103, "instance_name": "mysql_prod"}
DEFAULT_USER = {"assigneeid": "101"}
DEFAULT_DB = {"database_id": 105, "database_name": "dbgpt_test"}

# submit json data by post request.
def post_json_data(url: str, json_data: dict):
    response = requests.post(url, data=json.dumps(json_data), headers=get_auth_header())
    if response.status_code == requests.codes.ok:
        return response.json()
    else:
        return None


# send GET request with header
def get_with_header(url: str, headers: dict):
    response = requests.get(url, headers=headers)
    if response.status_code == requests.codes.ok:
        return response.json()
    else:
        return None


## auth header info 
def get_auth_header():
    headers = {
        "Cookie": "user=101; access-token=eyJhbGciOiJIUzI1NiIsImtpZCI6InYxIiwidHlwIjoiSldUIn0.eyJuYW1lIjoicm9vdCIsImlzcyI6ImJ5dGViYXNlIiwic3ViIjoiMTAxIiwiYXVkIjpbImJiLnVzZXIuYWNjZXNzLnByb2QiXSwiZXhwIjoxNjg1NTgzOTAwLCJpYXQiOjE2ODU0OTc1MDB9.KX9E5oxvevRnBzbMkS5V0dvNIHbiHBbRfXwToAAjt5A; refresh-token=eyJhbGciOiJIUzI1NiIsImtpZCI6InYxIiwidHlwIjoiSldUIn0.eyJuYW1lIjoicm9vdCIsImlzcyI6ImJ5dGViYXNlIiwic3ViIjoiMTAxIiwiYXVkIjpbImJiLnVzZXIucmVmcmVzaC5wcm9kIl0sImV4cCI6MTY4NjEwMjMwMCwiaWF0IjoxNjg1NDk3NTAwfQ._i-A0SsycRtdF1DwPxREDf7q7WgiMVDi3xcw3IZqaJs",
        "Content-type": "application/json",
    }
    return headers


# create database by param CreateReq, and return Response.json
def create_database(database_name: str, env: str, description: str):
    url = bytebase_domain + bb_db_create_url

    ## default set to test env.
    if env.lower() != "prod" and env.lower() != "test":
        env = DEFAULT_ENV["env_name"]

    labels = [{
        "key": "bb.environment",
        "value": env.lower()
    }]

    instance_id = None
    if env.lower() == "prod":
        instance_id = DEFAULT_INSTANCE_PROD["instance_id"]
    else:
        instance_id = DEFAULT_INSTANCE_TEST["instance_id"]

    createContext = {
        "instanceId": instance_id,
        "databaseName": database_name,
        "tableName": "",
        "owner": "",
        "characterSet": "utf8mb4",
        "collation": "utf8mb4_general_ci",
        "cluster": "",
        "labels": json.dumps(labels)
    }

    request = {
        "data": {
            "type": "IssueCreate",
            "attributes": {
                "name": f"Create database '{database_name}'",
                "type": "bb.issue.database.create",
                "description": description,
                "assigneeId": 1,
                "projectId": DEFAULT_PROJECT["project_id"],
                "pipeline": {
                    "stageList": [],
                    "name": ""
                },
                "createContext": json.dumps(createContext),
                "payload": "{}"
            }
        }
    }
    response_json = post_json_data(url, request)
    return parse_create_result(response_json)    


## 解析并查询创建过程
def parse_create_result(response_json):    
    response_data = response_json["data"]
    issue_id = None
    if response_data and response_data.get("id"):
        issue_id = response_data["id"]
    if issue_id != None:
        ## 请求查询建库状态
        count = 0;
        while True:
            query_json = query_database_status(issue_id)
            if query_json and query_json["data"]:
                query_json_data = query_json["data"]
                if query_json_data and query_json_data["attributes"] and query_json_data["attributes"]["status"]:
                    status = query_json_data["attributes"]["status"]
                    if status == "DONE":
                        return {"status": "success", "msg": "issue status: DONE", "url": bb_overview_url}
                    elif status == "OPEN":
                        if query_json["included"]:
                            for step in query_json["included"]:
                                if step["type"] and step["type"] == 'taskRun' and step["attributes"] and step["attributes"]["status"] and step["attributes"]["status"] == "FAILED":
                                    return {"status": "failed", "msg": "create database failed, " + step["attributes"]["result"]}
                    else:
                        return {"status": "failed", "msg": f"issue status: {status}", "url": bb_overview_url}
            time.sleep(1)
            count = count + 1
            if count > 5:
                break
    return {"status": "running", "msg": f"create database timeout, please check in the bytebase service!", "url": bb_issue_url}


# query database status
def query_database_status(issue_id: int):
    url = bytebase_domain + bb_db_query_url.format(issue_id)
    return get_with_header(url, get_auth_header())


### 1. createSheet; 2.IssueCreate 3. GET Create Table Status

## create table sheet
def create_sheet(statement: str, database_name: str):
    now = datetime.datetime.now()
    readable_time = now.strftime("%Y-%m-%d %H:%M:%S")

    request = {
    	"data": {
            "type": "createSheet",
            "attributes": {
                "projectId": DEFAULT_PROJECT["project_id"],
                "name": f"[{database_name}] Alter schema {readable_time} - {database_name}",
                "statement": statement,
                "visibility": "PROJECT",
                "source": "BYTEBASE_ARTIFACT",
                "payload": "{}"
            }
	    }
    }
    response_data = post_json_data(bytebase_domain + bb_create_sheet_url, request)
    if response_data and response_data["data"] and response_data["data"]["id"]:
        sheet_id = response_data["data"]["id"]
        if is_integer(sheet_id):
            return int(sheet_id)
    return None

def get_database_id_by_name(database_name: str):
    database_id = None
    database_list = query_databases()
    for db in database_list:
        if db["database_name"] and db["database_name"] == database_name:
            database_id = int(db["database_id"])
    return database_id


## execute create table by sheet_id
def create_issue(sheet_id: int, database_name: str):
    database_id = get_database_id_by_name(database_name)    
    now = datetime.datetime.now()
    readable_time = now.strftime("%Y-%m-%d %H:%M:%S")

    createContext = {
        "detailList": [{
            "migrationType": "MIGRATE",
            "databaseId": database_id,
            "statement": "",
            "sheetId": sheet_id,
            "earliestAllowedTs": 0
        }]
    }
    request = {
        "data": {
            "type": "IssueCreate",
            "attributes": {
                "projectId": DEFAULT_PROJECT["project_id"],
                "name": f"[{database_name}] Alter schema {readable_time} - {database_name}",
                "type": "bb.issue.database.schema.update",
                "description": "",
                "assigneeId": 101,
                "createContext": json.dumps(createContext),
                "payload": "{}"
            }
        }
    }
    response_data = post_json_data(bytebase_domain + bb_db_create_url, request)
    if response_data and response_data["data"] and response_data["data"]["id"]:
        return response_data["data"]["id"]
    return None

# query issue status by issue_id
def get_create_table_result(issue_id: str, database_name: str):
    if not issue_id:
        return {"status": "failed", "msg": "the issue is not exist!"}
    response_data = get_with_header(bytebase_domain + bb_db_query_url.format(issue_id), get_auth_header())
    if response_data and response_data["data"] and response_data["data"]["attributes"] and response_data["data"]["attributes"]["status"]:
        create_table_status = response_data["data"]["attributes"]["status"]
        if "DONE" == create_table_status:
            return {"status": "success", "msg": "update schema success! " + bb_database_detail_page_template.format(database_name, get_database_id_by_name(database_name))}
        elif "OPEN" == create_table_status:
            if response_data["included"]:
                for step in response_data["included"]:
                    if step["type"] and step["type"] == 'taskRun' and step["attributes"] and step["attributes"]["status"] and step["attributes"]["status"] == "FAILED":
                        return {"status": "failed", "msg": "update schema failed, " + step["attributes"]["result"]}
        else:
            return {"status": "failed", "msg": f"update schema status={create_table_status}!"}
    return {"status": "running", "msg": "the issue is running."}

## create table .
def create_table(statement: str, database_name: str):
    sheet_id = create_sheet(statement, database_name)
    if not sheet_id:
        return {"status": "failed", "msg": f"create table fail, sql= {statement}"}
    issue_id = create_issue(sheet_id, database_name)
    if not issue_id:
        return {"status": "failed", "msg": "the issue is not exist!"}
    count = 0
    while True:
        create_result = get_create_table_result(issue_id, database_name)
        if create_result and create_result["status"] == "success":
            return create_result
        elif create_result and create_result["status"] == "failed":
            return create_result
        time.sleep(1)
        count = count + 1
        if count > 20:
            break;
    return {"status": "running", "msg": f"update schema timeout! please skip to url: {bb_issue_url}"}


def is_integer(s):
    try:
        int(s)  # 尝试将字符串转化为整数
        return True  # 转换成功，说明是整数
    except ValueError:
        return False  # 转换失败，说明不是整数


## query all instance
def query_instance_list():
    response_data = get_with_header(bytebase_domain + bb_instance_url, get_auth_header())
    instance_list = []
    if response_data and response_data["data"]:
        for instance in response_data["data"]:
            if instance["type"] and instance["type"] == "instance" and instance["attributes"] and instance["attributes"]["name"] :
                instance_list.append({"instance_id": instance["id"], "instance_name": instance["attributes"]["name"]})
    return instance_list


## query instance by env
def query_instance_list_by_env(env_str: str):
    response_data = get_with_header(bytebase_domain + bb_instance_url, get_auth_header())
    instance_list = []

    required_env_id = None
    if response_data and response_data["included"]:
        for env in response_data["included"]:
            if env["type"] and env["type"] == "environment" and env["attributes"] and env["attributes"]["name"] and env["attributes"]["name"].lower() == env_str.lower():
                required_env_id = env["id"]    
    print(f"query_instance_list_by_env(): required_env={env_str}, required_env_id={required_env_id}")

    if response_data and response_data["data"]:
        for instance in response_data["data"]:
            if instance["type"] and instance["type"] == "instance":
                if instance["relationships"] and instance["relationships"]["environment"] and instance["relationships"]["environment"]["data"] and instance["relationships"]["environment"]["data"]["type"] == "environment":
                    if instance["relationships"]["environment"]["data"]["id"] == required_env_id:
                        instance_list.append({"instance_id": instance["id"], "instance_name": instance["attributes"]["name"]})
    return instance_list


## query env list
def query_env_list():
    env_list = []
    response_data = get_with_header(bytebase_domain + bb_instance_url, get_auth_header())
    if response_data and response_data["included"]:
        for env in response_data["included"]:
            if env["type"] and env["type"] == "environment":
                env_list.append({"env_id": env["id"], "env_name": env["attributes"]["name"]})
    return env_list


## query project list
def query_project_list():
    project_list = []
    response_data = get_with_header(bytebase_domain + bb_project_url, get_auth_header())

    if response_data and response_data["data"]:
        for project in response_data["data"]:
            if project["type"] and project["type"] == "project" and project["attributes"] and project["attributes"]["name"]:
                project_list.append({"project_id": project["id"], "project_name": project["attributes"]["name"]})
    return project_list


# query project with a default value.
def query_project_with_default(project_name: str):
    project_list = query_project_list()
    for proj in project_list:
        if proj["project_name"].lower() == project_name.lower():
            return proj["project_id"]
    return DEFAULT_PROJECT["project_id"]


# 查询全部数据库
def query_databases():
    database_list = []
    response_data = get_with_header(bytebase_domain + bb_database_url, get_auth_header())
    if response_data and response_data["data"]:
        for database in response_data["data"]:
            labels = json.loads(database["attributes"]["labels"])
            env_name = None
            for label in labels:
                if label["key"] and label["key"] == "bb.environment" and label["value"]:
                    env_name = label["value"]
                    break 
            database_list.append({"database_name": database["attributes"]["name"], "instance_id": database["attributes"]["instanceId"], "project_id": database["attributes"]["projectId"], "database_id": database["id"], "env_name": env_name})
    return database_list

###################################################################
##  test create database by bytebase  ##################################
# ret = create_database("dbgpt_test15", "test", "create database test.")
# print(ret)


###################################################################
##  test create table by bytebase  ##################################
# statement = """
#         CREATE TABLE `pz_job_v2` (
#             `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
#             `gmt_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
#             `gmt_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
#             `job_id` varchar(100) NOT NULL COMMENT '任务id',
#             `job_name` varchar(1000) NOT NULL DEFAULT '' COMMENT '任务名称',
#             `job_type` varchar(255) NOT NULL COMMENT '任务类型',
#             `job_mode` varchar(100) NOT NULL COMMENT '任务模式',
#             `content` text DEFAULT NULL COMMENT '任务参数',
#             `pre_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '上次执行时间',
#             `next_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '下次执行时间',
#             `job_interval` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '时间间隔',
#             `instance` varchar(50) DEFAULT '' COMMENT '指定运行实例',
#             `status` varchar(50) NOT NULL DEFAULT '' COMMENT '任务状态',
#             PRIMARY KEY (`id`)
#         ) AUTO_INCREMENT = 1001 DEFAULT CHARSET = utf8mb4;
#     """;

# statement = "CREATE INDEX idx_job_type ON pz_job_v2(job_type);"


# # create_table_result = create_table(statement, DEFAULT_DB["database_name"])
# create_table_result = create_table(statement, "dbgpt_test13")
# print("create result ==========" + json.dumps(create_table_result))
# {"status": "success", "msg": "create table success!"}


## TODO 指定database建表，不使用默认库


###################################################################
##  test query project, env, instance  ##################################

# env_list = query_env_list()
# print(env_list)

# env_instance_list = query_instance_list_by_env("test")
# print(env_instance_list)

# instance_list = query_instance_list()
# print(instance_list)

# project_list = query_project_list()
# print(project_list)

# databases = query_databases()
# print(databases)

